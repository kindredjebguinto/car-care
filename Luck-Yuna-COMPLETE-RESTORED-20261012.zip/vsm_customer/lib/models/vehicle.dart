class Vehicle {
  final int id;
  final int? userId;
  final int customerId;
  final String brand;
  final String model;
  final String year;
  final String plateNumber;
  final String? color;
  final String? vehicleType;
  final String? transmission;
  final String? fuelType;
  final int? mileage;
  final String? vin;

  const Vehicle({
    required this.id,
    this.userId,
    required this.customerId,
    required this.brand,
    required this.model,
    required this.year,
    required this.plateNumber,
    this.color,
    this.vehicleType,
    this.transmission,
    this.fuelType,
    this.mileage,
    this.vin,
  });

  factory Vehicle.fromJson(Map<String, dynamic> json) {
    return Vehicle(
      id: int.parse(json['id'].toString()),
      userId: json['user_id'] == null
          ? null
          : int.tryParse(json['user_id'].toString()),
      customerId: int.parse(json['customer_id'].toString()),
      brand: json['brand']?.toString() ?? '',
      model: json['model']?.toString() ?? '',
      year: json['year']?.toString() ?? '',
      plateNumber: json['plate_number']?.toString() ?? '',
      color: json['color']?.toString(),
      vehicleType: json['vehicle_type']?.toString(),
      transmission: json['transmission']?.toString(),
      fuelType: json['fuel_type']?.toString(),
      mileage: int.tryParse(json['mileage']?.toString() ?? ''),
      vin: json['vin']?.toString(),
    );
  }
}
