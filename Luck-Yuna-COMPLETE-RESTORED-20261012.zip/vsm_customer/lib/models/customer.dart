class Customer {
  final int id;
  final int userId;
  final String fullname;
  final String email;
  final String? phone;
  final String? address;

  const Customer({
    required this.id,
    required this.userId,
    required this.fullname,
    required this.email,
    this.phone,
    this.address,
  });

  factory Customer.fromJson(Map<String, dynamic> json) {
    return Customer(
      id: int.parse(json['id'].toString()),
      userId: int.parse(json['user_id'].toString()),
      fullname: json['fullname']?.toString() ?? '',
      email: json['email']?.toString() ?? '',
      phone: json['phone']?.toString(),
      address: json['address']?.toString(),
    );
  }
}
