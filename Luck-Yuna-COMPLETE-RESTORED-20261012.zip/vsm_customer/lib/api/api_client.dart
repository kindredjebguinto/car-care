import 'dart:convert';
import 'package:http/http.dart' as http;
import '../services/session_service.dart';

class ApiClient {
  static Future<Map<String, String>> headers({bool json = false}) async {
    final token = await SessionService.getToken();
    return {
      'Accept': 'application/json',
      if (json) 'Content-Type': 'application/json',
      if (token != null && token.isNotEmpty) 'Authorization': 'Bearer $token',
    };
  }

  static Map<String, dynamic> decode(http.Response response) {
    try {
      final value = jsonDecode(response.body);
      if (value is Map<String, dynamic>) return value;
    } catch (_) {}
    throw Exception(
      'The server returned an invalid response (${response.statusCode}). '
      'Restart Apache and import mobile_api_migration.sql if this continues.',
    );
  }

  static Future<Map<String, dynamic>> get(String url) async {
    final response = await http.get(Uri.parse(url), headers: await headers())
        .timeout(const Duration(seconds: 15));
    return decode(response);
  }

  static Future<Map<String, dynamic>> post(String url, Map<String, dynamic> body) async {
    final response = await http.post(Uri.parse(url), headers: await headers(json: true), body: jsonEncode(body))
        .timeout(const Duration(seconds: 15));
    return decode(response);
  }

  static Future<Map<String, dynamic>> multipart(String url, Map<String, String> fields, {String? fieldName, String? filePath}) async {
    final request = http.MultipartRequest('POST', Uri.parse(url));
    request.headers.addAll(await headers());
    request.fields.addAll(fields);
    if (fieldName != null && filePath != null && filePath.isNotEmpty) {
      request.files.add(await http.MultipartFile.fromPath(fieldName, filePath));
    }
    final streamed = await request.send().timeout(const Duration(seconds: 30));
    return decode(await http.Response.fromStream(streamed));
  }

  static String message(Object error) => error.toString().replaceFirst('Exception: ', '');
}
