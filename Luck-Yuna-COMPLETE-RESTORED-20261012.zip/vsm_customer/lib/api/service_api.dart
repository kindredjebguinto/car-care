import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/service.dart';
import 'api_config.dart';
import 'api_client.dart';

class ServiceApi {
  static Future<List<Service>> getServices() async {
    try {
      final response = await http
          .get(
            Uri.parse(ApiConfig.servicesListUrl),
            headers: await ApiClient.headers(),
          )
          .timeout(const Duration(seconds: 15));

      final dynamic decoded = jsonDecode(response.body);

      if (decoded is! Map<String, dynamic>) {
        throw Exception('Invalid response from server.');
      }

      if (decoded['success'] != true) {
        throw Exception(
          decoded['message']?.toString() ?? 'Unable to retrieve services.',
        );
      }

      final dynamic serviceData = decoded['services'];

      if (serviceData is! List) {
        return [];
      }

      return serviceData
          .whereType<Map<String, dynamic>>()
          .map(Service.fromJson)
          .toList();
    } catch (e) {
      throw Exception(e.toString().replaceFirst('Exception: ', ''));
    }
  }
}
