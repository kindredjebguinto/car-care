import 'dart:convert';

import 'package:http/http.dart' as http;

import 'api_config.dart';
import 'api_client.dart';

class AuthApi {
  static Future<Map<String, dynamic>> login({
    required String email,
    required String password,
  }) async {
    try {
      final response = await http
          .post(
            Uri.parse(ApiConfig.loginUrl),
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
            },
            body: jsonEncode({'email': email, 'password': password}),
          )
          .timeout(const Duration(seconds: 15));

      final dynamic decoded = jsonDecode(response.body);

      if (decoded is! Map<String, dynamic>) {
        throw Exception('Invalid response from server.');
      }

      return decoded;
    } catch (e) {
      throw Exception('Unable to connect to the server: $e');
    }
  }

  static Future<Map<String, dynamic>> register({
    required String fullname,
    required String email,
    required String password,
    required String phone,
    required String address,
  }) async {
    try {
      final response = await http.post(
        Uri.parse(ApiConfig.registerUrl),
        headers: {'Content-Type': 'application/json', 'Accept': 'application/json'},
        body: jsonEncode({
          'fullname': fullname,
          'email': email,
          'password': password,
          'phone': phone,
          'address': address,
        }),
      ).timeout(const Duration(seconds: 15));
      final decoded = jsonDecode(response.body);
      if (decoded is! Map<String, dynamic>) {
        throw Exception('Invalid response from server.');
      }
      return decoded;
    } catch (e) {
      throw Exception('Unable to connect to the server: $e');
    }
  }

  static Future<Map<String, dynamic>> forgotPassword(String email) =>
      ApiClient.post(ApiConfig.forgotPasswordUrl, {'email': email});

  static Future<void> logout() async {
    try {
      await ApiClient.post(ApiConfig.logoutUrl, {});
    } catch (_) {
      // Local logout must still succeed when the server is unavailable.
    }
  }
}
