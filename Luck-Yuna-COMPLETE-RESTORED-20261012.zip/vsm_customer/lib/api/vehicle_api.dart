import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/vehicle.dart';
import 'api_config.dart';
import 'api_client.dart';

class VehicleApi {
  static Future<List<Vehicle>> getVehicles({required int customerId}) async {
    try {
      final uri = Uri.parse(ApiConfig.vehiclesListUrl)
          .replace(queryParameters: {'customer_id': customerId.toString()});

      final response = await http
          .get(uri, headers: await ApiClient.headers())
          .timeout(const Duration(seconds: 15));

      final dynamic decoded = jsonDecode(response.body);

      if (decoded is! Map<String, dynamic>) {
        throw Exception('Invalid response from server.');
      }

      if (decoded['success'] != true) {
        throw Exception(
          decoded['message']?.toString() ?? 'Unable to retrieve vehicles.',
        );
      }

      final dynamic vehicleData = decoded['vehicles'];

      if (vehicleData is! List) {
        return [];
      }

      return vehicleData
          .whereType<Map<String, dynamic>>()
          .map(Vehicle.fromJson)
          .toList();
    } catch (e) {
      throw Exception(e.toString().replaceFirst('Exception: ', ''));
    }
  }

  static Future<Map<String, dynamic>> addVehicle({
    required int customerId,
    required String brand,
    required String model,
    required String year,
    required String plateNumber,
    required String color,
    String vehicleType = '',
    String transmission = '',
    String fuelType = '',
    int? mileage,
    String vin = '',
  }) async {
    try {
      final response = await http
          .post(
            Uri.parse(ApiConfig.vehicleAddUrl),
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
              ...await ApiClient.headers(),
            },
            body: jsonEncode({
              'customer_id': customerId,
              'brand': brand,
              'model': model,
              'year': year,
              'plate_number': plateNumber,
              'color': color,
              'vehicle_type': vehicleType,
              'transmission': transmission,
              'fuel_type': fuelType,
              'mileage': mileage,
              'vin': vin,
            }),
          )
          .timeout(const Duration(seconds: 15));

      final dynamic decoded = jsonDecode(response.body);

      if (decoded is! Map<String, dynamic>) {
        throw Exception('Invalid response from server.');
      }

      return decoded;
    } catch (e) {
      throw Exception(e.toString().replaceFirst('Exception: ', ''));
    }
  }

  static Future<Map<String, dynamic>> updateVehicle({
    required int id,
    required int customerId,
    required String brand,
    required String model,
    required String year,
    required String plateNumber,
    required String color,
    String vehicleType = '',
    String transmission = '',
    String fuelType = '',
    int? mileage,
    String vin = '',
  }) async {
    try {
      final response = await http
          .post(
            Uri.parse(ApiConfig.vehicleUpdateUrl),
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
              ...await ApiClient.headers(),
            },
            body: jsonEncode({
              'id': id,
              'customer_id': customerId,
              'brand': brand,
              'model': model,
              'year': year,
              'plate_number': plateNumber,
              'color': color,
              'vehicle_type': vehicleType,
              'transmission': transmission,
              'fuel_type': fuelType,
              'mileage': mileage,
              'vin': vin,
            }),
          )
          .timeout(const Duration(seconds: 15));

      final dynamic decoded = jsonDecode(response.body);

      if (decoded is! Map<String, dynamic>) {
        throw Exception('Invalid response from server.');
      }

      return decoded;
    } catch (e) {
      throw Exception(e.toString().replaceFirst('Exception: ', ''));
    }
  }

  static Future<Map<String, dynamic>> deleteVehicle({
    required int id,
    required int customerId,
  }) async {
    try {
      final response = await http
          .post(
            Uri.parse(ApiConfig.vehicleDeleteUrl),
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
              ...await ApiClient.headers(),
            },
            body: jsonEncode({'id': id, 'customer_id': customerId}),
          )
          .timeout(const Duration(seconds: 15));

      final dynamic decoded = jsonDecode(response.body);

      if (decoded is! Map<String, dynamic>) {
        throw Exception('Invalid response from server.');
      }

      return decoded;
    } catch (e) {
      throw Exception(e.toString().replaceFirst('Exception: ', ''));
    }
  }
}
