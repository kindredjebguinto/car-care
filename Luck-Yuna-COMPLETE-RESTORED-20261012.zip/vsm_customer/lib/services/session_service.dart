import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SessionService {
  static const FlutterSecureStorage _storage = FlutterSecureStorage();

  static const String _loggedInKey = 'is_logged_in';
  static const String _customerIdKey = 'customer_id';
  static const String _customerNameKey = 'customer_name';
  static const String _customerEmailKey = 'customer_email';
  static const String _tokenKey = 'api_token';

  static Future<void> saveSession({
    required int customerId,
    required String name,
    required String email,
    required String token,
  }) async {
    await _storage.write(key: _loggedInKey, value: 'true');

    await _storage.write(key: _customerIdKey, value: customerId.toString());

    await _storage.write(key: _customerNameKey, value: name);

    await _storage.write(key: _customerEmailKey, value: email);
    await _storage.write(key: _tokenKey, value: token);
  }

  static Future<bool> isLoggedIn() async {
    final value = await _storage.read(key: _loggedInKey);
    final token = await _storage.read(key: _tokenKey);
    return value == 'true' && token != null && token.isNotEmpty;
  }

  static Future<int?> getCustomerId() async {
    final value = await _storage.read(key: _customerIdKey);

    if (value == null) {
      return null;
    }

    return int.tryParse(value);
  }

  static Future<String?> getCustomerName() {
    return _storage.read(key: _customerNameKey);
  }

  static Future<String?> getCustomerEmail() {
    return _storage.read(key: _customerEmailKey);
  }

  static Future<String?> getToken() => _storage.read(key: _tokenKey);

  static Future<void> updateIdentity({
    required String name,
    required String email,
  }) async {
    await _storage.write(key: _customerNameKey, value: name);
    await _storage.write(key: _customerEmailKey, value: email);
  }

  static Future<void> logout() async {
    await _storage.deleteAll();
  }
}
