import 'package:flutter/material.dart';

import '../../api/service_api.dart';
import '../../models/service.dart';

class ServicesScreen extends StatefulWidget {
  const ServicesScreen({super.key});

  @override
  State<ServicesScreen> createState() => _ServicesScreenState();
}

class _ServicesScreenState extends State<ServicesScreen> {
  bool _isLoading = true;

  String? _errorMessage;

  List<Service> _services = [];
  String _category = 'All';

  List<String> get _categories => ['All', ...{for (final service in _services) service.category}];
  List<Service> get _visibleServices => _category == 'All' ? _services : _services.where((service) => service.category == _category).toList();

  @override
  void initState() {
    super.initState();

    _loadServices();
  }

  Future<void> _loadServices() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final services = await ServiceApi.getServices();

      if (!mounted) return;

      setState(() {
        _services = services;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _errorMessage = e.toString().replaceFirst('Exception: ', '');
      });
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  String _formatPrice(double price) {
    return '₱${price.toStringAsFixed(2)}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F7F7),

      appBar: AppBar(
        title: const Text(
          'Services',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),

      body: RefreshIndicator(onRefresh: _loadServices, child: _buildBody()),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_errorMessage != null) {
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(24),
        children: [
          const SizedBox(height: 120),

          const Icon(Icons.error_outline, size: 64, color: Colors.red),

          const SizedBox(height: 16),

          Text(_errorMessage!, textAlign: TextAlign.center),

          const SizedBox(height: 20),

          Center(
            child: ElevatedButton.icon(
              onPressed: _loadServices,
              icon: const Icon(Icons.refresh),
              label: const Text('Try Again'),
            ),
          ),
        ],
      );
    }

    if (_services.isEmpty) {
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(24),
        children: [
          const SizedBox(height: 120),

          Icon(Icons.build_outlined, size: 72, color: Colors.grey.shade400),

          const SizedBox(height: 16),

          const Text(
            'No services available',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold),
          ),

          const SizedBox(height: 8),

          Text(
            'Please check again later.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.grey.shade600),
          ),
        ],
      );
    }

    return Column(children: [
      SizedBox(height: 50, child: ListView.separated(padding: const EdgeInsets.fromLTRB(16, 8, 16, 4), scrollDirection: Axis.horizontal, itemCount: _categories.length, separatorBuilder: (_, __) => const SizedBox(width: 7), itemBuilder: (_, index) { final category = _categories[index]; return ChoiceChip(label: Text(category), selected: _category == category, onSelected: (_) => setState(() => _category = category)); })),
      Expanded(child: ListView.separated(
      physics: const AlwaysScrollableScrollPhysics(),

      padding: const EdgeInsets.fromLTRB(16, 12, 16, 30),

      itemCount: _visibleServices.length,

      separatorBuilder: (_, __) => const SizedBox(height: 14),

      itemBuilder: (context, index) {
        final service = _visibleServices[index];

        return Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const CircleAvatar(
                      radius: 25,
                      child: Icon(Icons.build_outlined),
                    ),

                    const SizedBox(width: 14),

                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            service.serviceName,
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),

                          const SizedBox(height: 6),

                          Text(
                            service.description.isEmpty
                                ? 'Professional vehicle service.'
                                : service.description,
                            style: TextStyle(color: Colors.grey.shade700),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 18),

                const Divider(),

                const SizedBox(height: 8),

                Row(
                  children: [
                    Expanded(
                      child: Text(
                        _formatPrice(service.price),
                        style: const TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFFD71920),
                        ),
                      ),
                    ),

                    if (service.estimatedDuration != null)
                      Row(
                        children: [
                          const Icon(Icons.schedule, size: 18),
                          const SizedBox(width: 5),
                          Text('${service.estimatedDuration} mins'),
                        ],
                      ),
                  ],
                ),

                const SizedBox(height: 16),

                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: () {
                      // Appointment/service
                      // selection comes next.
                    },
                    icon: const Icon(Icons.calendar_month),
                    label: const Text('Select Service'),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    )),]);
  }
}
