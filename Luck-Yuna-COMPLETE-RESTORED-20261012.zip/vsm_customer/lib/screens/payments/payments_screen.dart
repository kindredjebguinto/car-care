import 'package:flutter/material.dart';
import '../../api/customer_api.dart';
import '../../widgets/app_widgets.dart';
import 'booking_payment_screen.dart';
import 'receipt_screen.dart';

class PaymentsScreen extends StatefulWidget {
  const PaymentsScreen({super.key});

  @override
  State<PaymentsScreen> createState() => _PaymentsScreenState();
}

class _PaymentsScreenState extends State<PaymentsScreen> {
  List<Map<String, dynamic>> _items = [];
  bool _loading = true;
  String? _error;
  String _filter = 'All';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final items = await CustomerApi.payments();
      if (!mounted) return;
      setState(() {
        _items = items;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error.toString().replaceFirst('Exception: ', '');
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Payments')),
      body: RefreshIndicator(
        onRefresh: _load,
        child: _buildBody(),
      ),
    );
  }

  Widget _buildBody() {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_items.isEmpty) {
      return ListView(
        children: [
          EmptyState(
            icon: Icons.credit_card_off,
            title: 'No Payment Records',
            message: _error ??
                'Payment records created by staff will appear here.',
          ),
        ],
      );
    }

    final filtered = _items.where((payment) {
      final status = payment['payment_status']?.toString() ?? '';
      if (_filter == 'To Pay') return status == 'Awaiting Proof' || status == 'Rejected' || status == 'Pay at Shop';
      if (_filter == 'Review') return status == 'Under Review';
      if (_filter == 'Paid') return status == 'Paid';
      return true;
    }).toList();

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: filtered.length + 1,
      itemBuilder: (context, index) {
        if (index == 0) return Padding(padding: const EdgeInsets.only(bottom: 14), child: SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: ['All','To Pay','Review','Paid'].map((value) => Padding(padding: const EdgeInsets.only(right: 8), child: ChoiceChip(label: Text(value), selected: _filter == value, onSelected: (_) => setState(() => _filter = value)))).toList())));
        final payment = filtered[index - 1];
        final reservationId = payment['reservation_id'];
        final service = payment['service_type'] ?? '';
        final brand = payment['brand'] ?? '';
        final model = payment['model'] ?? '';
        final method = payment['payment_method'] ?? '';
        final date = payment['appointment_date'] ?? '';
        final status = payment['payment_status']?.toString() ?? '';

        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [CircleAvatar(child: Text('#$reservationId')), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(service, style: const TextStyle(fontWeight: FontWeight.bold)), Text('$brand $model • $date')])), StatusChip(status)]),
            const Divider(height: 24),
            Row(children: [Text(status == 'Paid' ? 'Amount paid' : 'Amount due'), const Spacer(), Text(money(payment['amount']), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: primaryColor))]),
            if (method != 'Not Selected' && method.isNotEmpty) Text('$method${(payment['reference_number'] ?? '').toString().isEmpty ? '' : ' • ${payment['reference_number']}'}', style: TextStyle(color: Colors.grey.shade600)),
            if ((payment['admin_notes'] ?? '').toString().isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text('Admin note: ${payment['admin_notes']}', style: const TextStyle(color: Colors.red))),
            const SizedBox(height: 12),
            if (status == 'Awaiting Proof' || status == 'Rejected') SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BookingPaymentScreen(paymentId: int.parse(payment['payment_id'].toString()), initialPayment: payment))).then((_) => _load()), icon: const Icon(Icons.payment), label: const Text('Pay This Booking'))),
            if (status == 'Under Review') const Row(children: [Icon(Icons.hourglass_top, size: 18), SizedBox(width: 8), Text('Waiting for admin verification')]),
            if (status == 'Pay at Shop') Row(children: [const Expanded(child: Text('Pay cash at the service counter. No proof required.')), TextButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BookingPaymentScreen(paymentId: int.parse(payment['payment_id'].toString()), initialPayment: payment))).then((_) => _load()), child: const Text('View'))]),
            if (status == 'Paid') Align(alignment: Alignment.centerRight, child: TextButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ReceiptScreen(paymentId: int.parse(payment['payment_id'].toString())))), icon: const Icon(Icons.receipt_long), label: const Text('View Receipt'))),
          ])),
        );
      },
    );
  }

}
