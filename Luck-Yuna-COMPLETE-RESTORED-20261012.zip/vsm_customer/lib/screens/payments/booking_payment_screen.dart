import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../../api/customer_api.dart';
import '../../widgets/app_widgets.dart';
import 'receipt_screen.dart';

class BookingPaymentScreen extends StatefulWidget {
  final int paymentId;
  final Map<String, dynamic>? initialPayment;

  const BookingPaymentScreen({required this.paymentId, this.initialPayment, super.key});

  @override
  State<BookingPaymentScreen> createState() => _BookingPaymentScreenState();
}

class _BookingPaymentScreenState extends State<BookingPaymentScreen> {
  Map<String, dynamic>? _payment;
  bool _loading = true;
  bool _submitting = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _payment = widget.initialPayment;
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = _payment == null;
      _error = null;
    });
    try {
      final payments = await CustomerApi.payments();
      final matches = payments.where((item) => item['payment_id'].toString() == widget.paymentId.toString());
      if (!mounted) return;
      setState(() {
        _payment = matches.isEmpty ? _payment : matches.first;
        _loading = false;
        if (_payment == null) _error = 'This payment record is not available.';
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = error.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Pay This Booking')),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : _payment == null
                ? EmptyState(icon: Icons.error_outline, title: 'Unable to Load Payment', message: _error ?? 'Please try again.')
                : RefreshIndicator(
                    onRefresh: _load,
                    child: ListView(padding: const EdgeInsets.all(16), children: [_paymentCard(_payment!)]),
                  ),
      );

  Widget _paymentCard(Map<String, dynamic> payment) {
    final status = payment['payment_status']?.toString() ?? '';
    final method = payment['payment_method']?.toString() ?? '';
    final reference = payment['reference_number']?.toString() ?? '';
    final service = payment['service_type']?.toString() ?? 'Vehicle service';
    final vehicle = '${payment['brand'] ?? ''} ${payment['model'] ?? ''}'.trim();
    final date = payment['appointment_date']?.toString() ?? '';

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Card(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [Expanded(child: Text(service, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold))), StatusChip(status)]),
            const SizedBox(height: 6),
            Text('$vehicle${date.isEmpty ? '' : ' • $date'}', style: TextStyle(color: Colors.grey.shade600)),
            const Divider(height: 30),
            const Text('TOTAL AMOUNT DUE', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text(money(payment['amount']), style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: primaryColor)),
          ]),
        ),
      ),
      const SizedBox(height: 12),
      if (status == 'Awaiting Proof' || status == 'Rejected') ...[
        if (status == 'Rejected' && (payment['admin_notes'] ?? '').toString().isNotEmpty)
          Card(color: Colors.red.shade50, child: ListTile(leading: const Icon(Icons.info_outline, color: Colors.red), title: const Text('Payment needs correction'), subtitle: Text(payment['admin_notes'].toString()))),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Choose How to Pay', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              const Text('Online payments require a reference number and proof image. Cash is paid at the service counter.'),
              const SizedBox(height: 16),
              SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _submitting ? null : () => _choosePayment(payment), icon: _submitting ? const SizedBox.square(dimension: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.lock_outline), label: Text(_submitting ? 'SUBMITTING...' : 'CONTINUE TO PAYMENT'))),
            ]),
          ),
        ),
      ] else if (status == 'Pay at Shop')
        Card(color: const Color(0xFFFFF7E0), child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Row(children: [Icon(Icons.storefront, color: Colors.orange), SizedBox(width: 10), Expanded(child: Text('Pay cash at the service counter', style: TextStyle(fontWeight: FontWeight.bold)))]), const SizedBox(height: 8), const Text('No proof image is required. Your receipt will appear after staff confirms that cash was received.'), const SizedBox(height: 12), TextButton(onPressed: _submitting ? null : () => _choosePayment(payment), child: const Text('Change payment method'))])))
      else if (status == 'Under Review')
        const Card(child: ListTile(contentPadding: EdgeInsets.all(18), leading: Icon(Icons.hourglass_top, color: primaryColor), title: Text('Payment under review', style: TextStyle(fontWeight: FontWeight.bold)), subtitle: Text('The service center is checking your proof. No further action is needed.')))
      else if (status == 'Paid') ...[
        Card(child: ListTile(contentPadding: const EdgeInsets.all(18), leading: const Icon(Icons.check_circle, color: Colors.green), title: const Text('Payment completed', style: TextStyle(fontWeight: FontWeight.bold)), subtitle: Text([method, reference].where((value) => value.isNotEmpty && value != 'Not Selected').join(' • ')))),
        const SizedBox(height: 8),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ReceiptScreen(paymentId: widget.paymentId))), icon: const Icon(Icons.receipt_long), label: const Text('VIEW RECEIPT'))),
      ],
    ]);
  }

  Future<void> _choosePayment(Map<String, dynamic> payment) async {
    String method = 'GCash';
    final isReservationFee=payment['payment_type']?.toString()=='Reservation Fee';
    final paymentMethods=isReservationFee?['GCash','Maya','Bank Transfer','Card']:['GCash','Maya','Bank Transfer','Card','Cash'];
    final reference = TextEditingController();
    XFile? proof;
    String? validationMessage;

    final submission = await showDialog<_PaymentSubmission>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) {
          final isCash = method == 'Cash';
          return AlertDialog(
            title: const Text('Payment Method'),
            content: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                DropdownButtonFormField<String>(
                  initialValue: method,
                  decoration: const InputDecoration(labelText: 'Choose method', border: OutlineInputBorder()),
                  items: paymentMethods.map((value) => DropdownMenuItem(value: value, child: Text(value == 'Cash' ? 'Cash at Shop' : value))).toList(),
                  onChanged: (value) => setDialogState(() { method = value ?? method; validationMessage = null; }),
                ),
                const SizedBox(height: 14),
                if(isReservationFee)const Padding(padding:EdgeInsets.only(bottom:12),child:Text('The ₱200 reservation fee must be paid online. Cash at Shop is not available for app reservations.',style:TextStyle(fontSize:12,fontWeight:FontWeight.w600))),
                if (isCash)
                  const Card(color: Color(0xFFFFF7E0), child: Padding(padding: EdgeInsets.all(12), child: Text('Pay the exact amount at the service counter. No proof image or transaction reference is required.')))
                else ...[
                  if(method=='GCash')Center(child:Column(children:[Container(color:Colors.white,padding:const EdgeInsets.all(10),child:CustomPaint(size:const Size(150,150),painter:_DemoQrPainter())),const SizedBox(height:6),const Text('DEMO GCASH QR — replace with the shop’s official QR',textAlign:TextAlign.center,style:TextStyle(fontSize:11,fontWeight:FontWeight.bold))])),
                  if(method=='GCash')const SizedBox(height:14),
                  TextField(controller: reference, textCapitalization: TextCapitalization.characters, decoration: const InputDecoration(labelText: 'Transaction Reference Number', hintText: 'Required', border: OutlineInputBorder())),
                  const SizedBox(height: 12),
                  if (proof != null) ...[
                    ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.file(File(proof!.path), height: 150, width: double.infinity, fit: BoxFit.cover)),
                    const SizedBox(height: 8),
                  ],
                  SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: () async { final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 85); if (picked != null) setDialogState(() { proof = picked; validationMessage = null; }); }, icon: const Icon(Icons.image_outlined), label: Text(proof == null ? 'Choose Proof Image' : 'Change Proof Image'))),
                  const Text('JPG, PNG or WEBP • maximum 5 MB', style: TextStyle(fontSize: 12)),
                ],
                if (validationMessage != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(validationMessage!, style: const TextStyle(color: Colors.red))),
              ]),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
              FilledButton(
                onPressed: () {
                  if (!isCash && reference.text.trim().isEmpty) { setDialogState(() => validationMessage = 'Enter the transaction reference number.'); return; }
                  if (!isCash && proof == null) { setDialogState(() => validationMessage = 'Choose a payment proof image.'); return; }
                  Navigator.pop(dialogContext, _PaymentSubmission(method: method, reference: reference.text.trim(), proof: proof));
                },
                child: Text(isCash ? 'SELECT CASH' : 'SUBMIT PROOF'),
              ),
            ],
          );
        },
      ),
    );
    reference.dispose();
    if (submission == null || !mounted) return;

    setState(() => _submitting = true);
    try {
      final result = await CustomerApi.submitPayment(paymentId: widget.paymentId, method: submission.method, reference: submission.reference, filePath: submission.proof?.path);
      if (!mounted) return;
      final success = result['success'] == true;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(result['message']?.toString() ?? (success ? 'Payment submitted.' : 'Unable to submit payment.')), backgroundColor: success ? Colors.green : Colors.red));
      if (success) await _load();
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.toString().replaceFirst('Exception: ', '')), backgroundColor: Colors.red));
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }
}

class _PaymentSubmission {
  final String method;
  final String reference;
  final XFile? proof;
  const _PaymentSubmission({required this.method, required this.reference, required this.proof});
}

class _DemoQrPainter extends CustomPainter {
  @override void paint(Canvas canvas,Size size){final paint=Paint()..color=Colors.black;const grid=21.0;final cell=size.width/grid;bool dark(int x,int y){if((x<7&&y<7)||(x>13&&y<7)||(x<7&&y>13)){final lx=x<7?x:x-14,ly=y<7?y:y-14;return lx==0||lx==6||ly==0||ly==6||(lx>=2&&lx<=4&&ly>=2&&ly<=4);}return ((x*3+y*5+x*y)%7)<3;}for(var y=0;y<21;y++){for(var x=0;x<21;x++){if(dark(x,y))canvas.drawRect(Rect.fromLTWH(x*cell,y*cell,cell+.3,cell+.3),paint);}}}
  @override bool shouldRepaint(covariant CustomPainter oldDelegate)=>false;
}
