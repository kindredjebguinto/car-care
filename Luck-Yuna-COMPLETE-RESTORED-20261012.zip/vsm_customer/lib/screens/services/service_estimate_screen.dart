import 'package:flutter/material.dart';

import '../../api/service_api.dart';
import '../../models/service.dart';
import '../../widgets/app_widgets.dart';
import '../reservations/book_service_screen.dart';

class ServiceEstimateScreen extends StatefulWidget {
  const ServiceEstimateScreen({super.key});

  @override
  State<ServiceEstimateScreen> createState() => _ServiceEstimateScreenState();
}

class _ServiceEstimateScreenState extends State<ServiceEstimateScreen> {
  final _search = TextEditingController();
  final Set<int> _selected = {};
  List<Service> _services = [];
  bool _loading = true;
  String? _error;
  String _category = 'All';

  List<String> get _categories => ['All', ...{for (final service in _services) service.category}];

  List<Service> get _visible {
    final query = _search.text.trim().toLowerCase();
    return _services.where((service) {
      final categoryMatches = _category == 'All' || service.category == _category;
      final queryMatches = query.isEmpty || service.serviceName.toLowerCase().contains(query) || service.description.toLowerCase().contains(query);
      return categoryMatches && queryMatches;
    }).toList();
  }

  List<Service> get _chosen => _services.where((item) => _selected.contains(item.id)).toList();
  double get _total => _chosen.fold(0, (sum, item) => sum + item.price);
  int get _minutes => _chosen.fold(0, (sum, item) => sum + (item.estimatedDuration ?? 0));

  @override
  void initState() { super.initState(); _load(); _search.addListener(() => setState(() {})); }

  @override
  void dispose() { _search.dispose(); super.dispose(); }

  Future<void> _load() async {
    try {
      final services = await ServiceApi.getServices();
      if (mounted) setState(() { _services = services; _loading = false; });
    } catch (e) {
      if (mounted) setState(() { _error = e.toString().replaceFirst('Exception: ', ''); _loading = false; });
    }
  }

  Future<void> _book() async {
    if (_selected.isEmpty) return;
    await Navigator.push(context, MaterialPageRoute(builder: (_) => BookServiceScreen(initialServiceIds: _selected.toList())));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Services & Estimate')),
    body: _loading ? const Center(child: CircularProgressIndicator())
      : _error != null ? EmptyState(icon: Icons.cloud_off, title: 'Unable to Load Services', message: _error!)
      : Column(children: [
        Expanded(child: ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 140), children: [
          Card(color: const Color(0xFFFFF1F2), child: const Padding(padding: EdgeInsets.all(18), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(Icons.request_quote_outlined, color: primaryColor), SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Build your service estimate', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), SizedBox(height: 5), Text('Check all services you are interested in. You can review the estimated cost before deciding to book.')]))
          ]))),
          const SizedBox(height: 12),
          TextField(controller: _search, decoration: InputDecoration(hintText: 'Search services', prefixIcon: const Icon(Icons.search), suffixIcon: _search.text.isEmpty ? null : IconButton(onPressed: _search.clear, icon: const Icon(Icons.close)), border: const OutlineInputBorder())),
          const SizedBox(height: 10),
          SizedBox(height: 38, child: ListView.separated(scrollDirection: Axis.horizontal, itemCount: _categories.length, separatorBuilder: (_, __) => const SizedBox(width: 7), itemBuilder: (_, index) { final category = _categories[index]; return ChoiceChip(label: Text(category), selected: _category == category, onSelected: (_) => setState(() => _category = category)); })),
          const SizedBox(height: 18),
          Row(children: [const Expanded(child: Text('Our Services', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))), Text('${_services.length} available', style: TextStyle(color: Colors.grey.shade600))]),
          const SizedBox(height: 8),
          if (_visible.isEmpty) const EmptyState(icon: Icons.search_off, title: 'No Service Found', message: 'Try a different search word.'),
          ..._visible.map(_serviceCard),
          const SizedBox(height: 12),
          Text('Prices shown are initial estimates. The final job quotation may include inspection findings, labor, parts, discounts, or taxes.', style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
        ])),
        if (_selected.isNotEmpty) _estimateBar(),
      ]),
  );

  Widget _serviceCard(Service service) {
    final selected = _selected.contains(service.id);
    return Card(margin: const EdgeInsets.only(bottom: 10), color: selected ? const Color(0xFFFFF7F7) : Colors.white, child: CheckboxListTile(
      value: selected,
      onChanged: (value) => setState(() => value == true ? _selected.add(service.id) : _selected.remove(service.id)),
      controlAffinity: ListTileControlAffinity.leading,
      title: Row(children: [Expanded(child: Text(service.serviceName, style: const TextStyle(fontWeight: FontWeight.bold))), Text(money(service.price), style: const TextStyle(fontWeight: FontWeight.bold, color: primaryColor))]),
      subtitle: Padding(padding: const EdgeInsets.only(top: 6), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(service.description), if(service.estimatedDuration != null) Padding(padding: const EdgeInsets.only(top: 5), child: Text('About ${service.estimatedDuration} minutes', style: TextStyle(color: Colors.grey.shade600))) ])),
      secondary: Icon(_icon(service.serviceName), color: primaryColor),
    ));
  }

  Widget _estimateBar() => Material(elevation: 12, color: Colors.white, child: SafeArea(top: false, child: Padding(padding: const EdgeInsets.fromLTRB(18, 14, 18, 14), child: Column(mainAxisSize: MainAxisSize.min, children: [
    Row(children: [Expanded(child: Text('${_selected.length} service${_selected.length == 1 ? '' : 's'} • about $_minutes min')), Text(money(_total), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: primaryColor))]),
    const SizedBox(height: 10), SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _book, icon: const Icon(Icons.calendar_month), label: const Padding(padding: EdgeInsets.symmetric(vertical: 13), child: Text('BOOK THESE SERVICES')))),
  ]))));

  IconData _icon(String name) { final value=name.toLowerCase(); if(value.contains('oil'))return Icons.oil_barrel;if(value.contains('brake'))return Icons.car_crash;if(value.contains('battery'))return Icons.battery_charging_full;if(value.contains('tire'))return Icons.tire_repair;if(value.contains('air'))return Icons.ac_unit;if(value.contains('engine'))return Icons.settings;return Icons.build_circle; }
}
