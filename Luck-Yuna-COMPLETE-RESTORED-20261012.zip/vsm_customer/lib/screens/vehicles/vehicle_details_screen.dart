import 'package:flutter/material.dart';

import '../../api/vehicle_api.dart';
import '../../models/vehicle.dart';
import '../../services/session_service.dart';
import 'edit_vehicle_screen.dart';

class VehicleDetailsScreen extends StatefulWidget {
  final Vehicle vehicle;

  const VehicleDetailsScreen({super.key, required this.vehicle});

  @override
  State<VehicleDetailsScreen> createState() => _VehicleDetailsScreenState();
}

class _VehicleDetailsScreenState extends State<VehicleDetailsScreen> {
  bool _isDeleting = false;

  Future<void> _deleteVehicle() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Delete Vehicle'),
          content: Text(
            'Are you sure you want to delete '
            '${widget.vehicle.brand} '
            '${widget.vehicle.model}?\n\n'
            'This action cannot be undone.',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(false);
              },
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () {
                Navigator.of(context).pop(true);
              },
              style: FilledButton.styleFrom(backgroundColor: Colors.red),
              child: const Text('Delete'),
            ),
          ],
        );
      },
    );

    if (confirmed != true) {
      return;
    }

    setState(() {
      _isDeleting = true;
    });

    try {
      final customerId = await SessionService.getCustomerId();

      if (customerId == null) {
        throw Exception('Customer session was not found.');
      }

      final result = await VehicleApi.deleteVehicle(
        id: widget.vehicle.id,
        customerId: customerId,
      );

      if (!mounted) return;

      if (result['success'] == true) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              result['message']?.toString() ?? 'Vehicle deleted successfully.',
            ),
            backgroundColor: Colors.green,
          ),
        );

        Navigator.of(context).pop(true);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              result['message']?.toString() ?? 'Unable to delete vehicle.',
            ),
            backgroundColor: Colors.red,
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(e.toString().replaceFirst('Exception: ', '')),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          _isDeleting = false;
        });
      }
    }
  }

  Widget _detailRow({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: const Color(0xFFD71920)),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
                ),
                const SizedBox(height: 4),
                Text(
                  value.isEmpty ? 'Not specified' : value,
                  style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final vehicle = widget.vehicle;

    return Scaffold(
      backgroundColor: const Color(0xFFF7F7F7),
      appBar: AppBar(
        title: const Text(
          'Vehicle Details',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            const Center(
              child: CircleAvatar(
                radius: 48,
                backgroundColor: Color(0xFFFFE4E6),
                child: Icon(
                  Icons.directions_car_rounded,
                  size: 52,
                  color: Color(0xFFD71920),
                ),
              ),
            ),

            const SizedBox(height: 20),

            Text(
              '${vehicle.brand} ${vehicle.model}',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
            ),

            const SizedBox(height: 6),

            Text(
              vehicle.plateNumber,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16, color: Colors.grey.shade600),
            ),

            const SizedBox(height: 28),

            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    _detailRow(
                      icon: Icons.business_outlined,
                      label: 'Brand',
                      value: vehicle.brand,
                    ),
                    const Divider(),
                    _detailRow(
                      icon: Icons.directions_car_outlined,
                      label: 'Model',
                      value: vehicle.model,
                    ),
                    const Divider(),
                    _detailRow(
                      icon: Icons.calendar_today_outlined,
                      label: 'Year',
                      value: vehicle.year,
                    ),
                    const Divider(),
                    _detailRow(
                      icon: Icons.confirmation_number_outlined,
                      label: 'Plate Number',
                      value: vehicle.plateNumber,
                    ),
                    const Divider(),
                    _detailRow(
                      icon: Icons.palette_outlined,
                      label: 'Color',
                      value: vehicle.color ?? '',
                    ),
                    if ((vehicle.vehicleType ?? '').isNotEmpty) ...[
                      const Divider(),
                      _detailRow(icon: Icons.category_outlined, label: 'Vehicle Type', value: vehicle.vehicleType!),
                    ],
                    if ((vehicle.transmission ?? '').isNotEmpty) ...[
                      const Divider(),
                      _detailRow(icon: Icons.settings_applications, label: 'Transmission', value: vehicle.transmission!),
                    ],
                    if ((vehicle.fuelType ?? '').isNotEmpty) ...[
                      const Divider(),
                      _detailRow(icon: Icons.local_gas_station, label: 'Fuel Type', value: vehicle.fuelType!),
                    ],
                    if (vehicle.mileage != null) ...[
                      const Divider(),
                      _detailRow(icon: Icons.speed, label: 'Mileage', value: '${vehicle.mileage} km'),
                    ],
                    if ((vehicle.vin ?? '').isNotEmpty) ...[
                      const Divider(),
                      _detailRow(icon: Icons.numbers, label: 'VIN / Chassis No.', value: vehicle.vin!),
                    ],
                  ],
                ),
              ),
            ),

            const SizedBox(height: 24),

            SizedBox(
              height: 52,
              child: ElevatedButton.icon(
                onPressed: () async {
                  final updated = await Navigator.of(context).push<bool>(
                    MaterialPageRoute(
                      builder: (_) =>
                          EditVehicleScreen(vehicle: widget.vehicle),
                    ),
                  );

                  if (updated == true && mounted) {
                    Navigator.of(context).pop(true);
                  }
                },
                icon: const Icon(Icons.edit_outlined),
                label: const Text('Edit Vehicle'),
              ),
            ),

            const SizedBox(height: 12),

            SizedBox(
              height: 52,
              child: OutlinedButton.icon(
                onPressed: _isDeleting ? null : _deleteVehicle,
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.red,
                  side: const BorderSide(color: Colors.red),
                ),
                icon: _isDeleting
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.delete_outline),
                label: Text(_isDeleting ? 'Deleting...' : 'Delete Vehicle'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
