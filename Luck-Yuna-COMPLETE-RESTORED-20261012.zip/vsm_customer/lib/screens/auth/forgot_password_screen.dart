import 'package:flutter/material.dart';
import '../../api/auth_api.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});
  @override State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final _email = TextEditingController();
  bool _loading = false;
  @override void dispose() { _email.dispose(); super.dispose(); }

  Future<void> _submit() async {
    if (!_email.text.contains('@')) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter a valid email address.')));
      return;
    }
    setState(() => _loading = true);
    try {
      final result = await AuthApi.forgotPassword(_email.text.trim());
      if (!mounted) return;
      await showDialog<void>(context: context, builder: (_) => AlertDialog(
        icon: const Icon(Icons.mark_email_read, size: 48),
        title: const Text('Request Submitted'),
        content: Text(result['message']?.toString() ?? ''),
        actions: [FilledButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
      ));
      if (mounted) Navigator.pop(context);
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.toString().replaceFirst('Exception: ', ''))));
    } finally { if (mounted) setState(() => _loading = false); }
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Forgot Password')),
    body: ListView(padding: const EdgeInsets.all(24), children: [
      const Icon(Icons.lock_reset, size: 72), const SizedBox(height: 20),
      const Text('Request password assistance', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
      const SizedBox(height: 8),
      const Text('Enter your registered email. The administrator will verify and resolve your reset request.', textAlign: TextAlign.center),
      const SizedBox(height: 28),
      TextField(controller: _email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email', prefixIcon: Icon(Icons.email), border: OutlineInputBorder())),
      const SizedBox(height: 18),
      FilledButton(onPressed: _loading ? null : _submit, child: Text(_loading ? 'SUBMITTING...' : 'SUBMIT REQUEST')),
    ]),
  );
}
