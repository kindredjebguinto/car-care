<?php

include_once __DIR__ . "/config.php";
include_once __DIR__ . "/admin_auth.php";
$current_admin_page = basename($_SERVER['PHP_SELF'] ?? '');
$admin_css_version = @filemtime(__DIR__ . '/../css/admin.css') ?: time();

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>
        Luck Yuna Car Center | Admin
    </title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
        rel="stylesheet">

    <link rel="stylesheet" href="<?= ADMIN_BASE_URL ?>/css/admin.css?v=<?= $admin_css_version ?>">

</head>

<body>

    <div class="admin-wrapper">

        <aside class="sidebar">

            <div class="sidebar-logo">

                <img src="<?= PUBLIC_BASE_URL ?>/images/logo.png" alt="Luck Yuna Car Center logo">
                <span>Luck Yuna<br><small>Car Center Admin</small></span>

            </div>

            <ul class="sidebar-menu">

                <li class="menu-label">OPERATIONS</li>

                <li>
                    <a class="<?= $current_admin_page === 'dashboard.php' ? 'active' : '' ?>" href="<?= ADMIN_BASE_URL ?>/dashboard.php">
                        📊 Dashboard
                    </a>
                </li>

                <li>
                    <a class="<?= in_array($current_admin_page, ['reservations.php','reservation_view.php','job_quotation.php'], true) ? 'active' : '' ?>" href="<?= ADMIN_BASE_URL ?>/reservations.php">
                        🧰 Jobs
                    </a>
                </li>

                <li>
                    <a class="<?= $current_admin_page === 'customers.php' ? 'active' : '' ?>" href="<?= ADMIN_BASE_URL ?>/customers.php">
                        👥 Customers
                    </a>
                </li>

                <li>
                    <a class="<?= str_contains($current_admin_page, 'mechanic') ? 'active' : '' ?>" href="<?= ADMIN_BASE_URL ?>/mechanics.php">
                        🔧 Team
                    </a>
                </li>

                <li>
                    <a class="<?= in_array($current_admin_page, ['services.php','service_add.php','service_edit.php'], true) ? 'active' : '' ?>" href="<?= ADMIN_BASE_URL ?>/services.php">
                        🛠 Services
                    </a>
                </li>

                <li>
                    <a class="<?= str_contains($current_admin_page, 'payment') ? 'active' : '' ?>" href="<?= ADMIN_BASE_URL ?>/payments.php">
                        💳 Finance
                    </a>
                </li>

                <li class="menu-label">INSIGHTS</li>
                <li>
                    <a class="<?= $current_admin_page === 'reports.php' ? 'active' : '' ?>" href="<?= ADMIN_BASE_URL ?>/reports.php">
                        📈 Reports
                    </a>
                </li>
                <li class="menu-label">SETTINGS</li>
                <?php if(($_SESSION['admin_staff_level']??'Staff')==='Manager'): ?><li><a class="<?= $current_admin_page === 'staff_accounts.php' ? 'active' : '' ?>" href="<?= ADMIN_BASE_URL ?>/staff_accounts.php">👤 Staff Accounts</a></li><?php endif; ?>
                <li>
                    <a class="<?= $current_admin_page === 'password_requests.php' ? 'active' : '' ?>" href="<?= ADMIN_BASE_URL ?>/password_requests.php">
                        ⚙️ Account Requests
                    </a>
                </li>
                <li><a class="<?= $current_admin_page === 'audit_logs.php' ? 'active' : '' ?>" href="<?= ADMIN_BASE_URL ?>/audit_logs.php">🧾 Activity Log</a></li>

                <li class="logout-item">
                    <a href="<?= ADMIN_BASE_URL ?>/logout.php"
   style="background-color: #dc2626; color: white; font-weight: bold; padding: 10px 18px; text-decoration: none; border-radius: 6px; display: inline-block;">
    🚪 Logout
</a>
                </li>

            </ul>

        </aside>

        <main class="admin-main">

            <header class="topbar">

                <div>

                    <strong>
                        Luck Yuna Car Center Admin
                    </strong>

                </div>

                <div class="admin-user">
                    <span class="admin-avatar"><?= strtoupper(substr($_SESSION['admin_name'] ?? 'S', 0, 1)) ?></span>
                    <span><small>Signed in as</small><strong><?= htmlspecialchars($_SESSION['admin_name'] ?? 'Staff'); ?></strong></span>
                </div>

            </header>

            <div class="admin-content">
