<?php

include "includes/config.php";


if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


$_SESSION = [];


/*
|--------------------------------------------------------------------------
| DELETE SESSION COOKIE
|--------------------------------------------------------------------------
*/

if (ini_get("session.use_cookies")) {

    $params =
        session_get_cookie_params();


    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );

}


session_destroy();


header(
    "Location: "
    . ADMIN_BASE_URL
    . "/login.php"
);


exit;