<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/config.php';
$customerLoggedIn = !empty($_SESSION['customer_id']);
$currentCustomerPage = basename($_SERVER['PHP_SELF'] ?? '');
$customerName = trim($_SESSION['customer_name'] ?? 'Customer');
$customerInitial = strtoupper(substr($customerName, 0, 1));
$pageTitles = ['dashboard.php'=>'Home','services.php'=>'Services & Estimate','book_service.php'=>'Book Service','reservations.php'=>'My Bookings','service_history.php'=>'Service History','vehicles.php'=>'My Vehicles','add_vehicle.php'=>'Add Vehicle','edit_vehicle.php'=>'Edit Vehicle','payments.php'=>'Payments & Receipts','profile.php'=>'My Account'];
$pageTitle = $pageTitles[$currentCustomerPage] ?? 'Customer Portal';
function customerNavActive(array $pages, string $current): string { return in_array($current, $pages, true) ? 'active' : ''; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#D71920">
    <title><?= htmlspecialchars($pageTitle) ?> | Luck Yuna Car Center</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/css/customer.css?v=20261001-red">
    <link rel="stylesheet" href="<?= BASE_URL ?>/css/service-tabs.css?v=20261001">
</head>
<body class="<?= $customerLoggedIn ? 'customer-app-body' : '' ?>">
<?php if ($customerLoggedIn): ?>
<header class="customer-appbar">
    <div class="customer-shell customer-appbar-inner">
        <a href="<?= BASE_URL ?>/customer/dashboard.php" class="customer-brand" aria-label="Luck Yuna Car Center home">
            <img src="<?= BASE_URL ?>/images/logo.png" alt="Luck Yuna Car Center logo">
            <span><strong>Luck Yuna</strong><small>Car Center</small></span>
        </a>
        <nav class="customer-desktop-nav" aria-label="Customer navigation">
            <a class="<?= customerNavActive(['dashboard.php'], $currentCustomerPage) ?>" href="<?= BASE_URL ?>/customer/dashboard.php"><i class="bi bi-house-door"></i> Home</a>
            <a class="<?= customerNavActive(['services.php'], $currentCustomerPage) ?>" href="<?= BASE_URL ?>/customer/services.php"><i class="bi bi-tools"></i> Services</a>
            <a class="<?= customerNavActive(['book_service.php','reservations.php'], $currentCustomerPage) ?>" href="<?= BASE_URL ?>/customer/reservations.php"><i class="bi bi-calendar3"></i> Bookings</a>
            <a class="<?= customerNavActive(['vehicles.php','add_vehicle.php','edit_vehicle.php','payments.php','profile.php','service_history.php'], $currentCustomerPage) ?>" href="<?= BASE_URL ?>/customer/profile.php"><i class="bi bi-person"></i> Account</a>
        </nav>
        <details class="customer-account-menu">
            <summary><span class="customer-avatar"><?= htmlspecialchars($customerInitial) ?></span><span class="customer-name"><?= htmlspecialchars($customerName) ?></span><i class="bi bi-chevron-down"></i></summary>
            <div class="customer-account-popover">
                <a href="<?= BASE_URL ?>/customer/vehicles.php"><i class="bi bi-car-front"></i> My Vehicles</a>
                <a href="<?= BASE_URL ?>/customer/payments.php"><i class="bi bi-receipt"></i> Payments & Receipts</a>
                <a href="<?= BASE_URL ?>/customer/service_history.php"><i class="bi bi-clock-history"></i> Service History</a>
                <a href="<?= BASE_URL ?>/customer/profile.php"><i class="bi bi-person-gear"></i> Profile & Password</a>
                <a class="logout-link" href="<?= BASE_URL ?>/customer/logout.php"><i class="bi bi-box-arrow-right"></i> Log out</a>
            </div>
        </details>
    </div>
</header>
<?php endif; ?>
<main class="customer-main">
<?php if ($customerLoggedIn): ?>
<nav class="customer-bottom-nav" aria-label="Mobile customer navigation">
    <a class="<?= customerNavActive(['dashboard.php'], $currentCustomerPage) ?>" href="<?= BASE_URL ?>/customer/dashboard.php"><i class="bi bi-house-door"></i><span>Home</span></a>
    <a class="<?= customerNavActive(['services.php'], $currentCustomerPage) ?>" href="<?= BASE_URL ?>/customer/services.php"><i class="bi bi-tools"></i><span>Services</span></a>
    <a class="<?= customerNavActive(['book_service.php','reservations.php'], $currentCustomerPage) ?>" href="<?= BASE_URL ?>/customer/reservations.php"><i class="bi bi-calendar3"></i><span>Bookings</span></a>
    <a class="<?= customerNavActive(['vehicles.php','add_vehicle.php','edit_vehicle.php','payments.php','profile.php','service_history.php'], $currentCustomerPage) ?>" href="<?= BASE_URL ?>/customer/profile.php"><i class="bi bi-person"></i><span>Account</span></a>
</nav>
<?php endif; ?>
