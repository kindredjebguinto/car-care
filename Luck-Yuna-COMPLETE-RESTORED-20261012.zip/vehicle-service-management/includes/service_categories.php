<?php

function service_category(string $serviceName): string
{
    $name = strtolower($serviceName);
    if (str_contains($name, 'pms') || str_contains($name, 'maintenance')) return 'PMS Packages';
    if (str_contains($name, 'oil') || str_contains($name, 'periodic')) return 'Oil & Periodic';
    if (str_contains($name, 'air conditioning') || str_contains($name, 'ac ')) return 'Air Conditioning';
    if (str_contains($name, 'brake')) return 'Brakes';
    if (str_contains($name, 'tire')) return 'Tires';
    if (str_contains($name, 'engine')) return 'Engine';
    if (str_contains($name, 'battery')) return 'Battery';
    return 'Other';
}

function service_category_slug(string $category): string
{
    return strtolower(trim(preg_replace('/[^a-z0-9]+/i', '-', $category), '-'));
}

function service_categories_for(array $services): array
{
    $preferred = ['PMS Packages', 'Oil & Periodic', 'Air Conditioning', 'Brakes', 'Tires', 'Engine', 'Battery', 'Other'];
    $available = [];
    foreach ($services as $service) $available[service_category($service['service_name'] ?? '')] = true;
    return array_values(array_filter($preferred, fn($category) => isset($available[$category])));
}
