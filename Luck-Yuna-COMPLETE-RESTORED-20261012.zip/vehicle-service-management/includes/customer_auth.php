<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/config.php';

if (!isset($_SESSION['customer_id'])) {

    header("Location: " . BASE_URL . "/login.php");
    exit();

}

if (
    !isset($_SESSION['customer_role']) ||
    $_SESSION['customer_role'] !== 'customer'
) {

    unset($_SESSION['customer_id']);
    unset($_SESSION['customer_name']);
    unset($_SESSION['customer_role']);

    header("Location: " . BASE_URL . "/login.php");
    exit();

}
