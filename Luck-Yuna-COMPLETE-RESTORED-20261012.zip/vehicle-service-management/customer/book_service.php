<?php
require_once __DIR__ . '/../includes/customer_auth.php';
require_once __DIR__ . '/../includes/service_categories.php';
$user_id = (int)$_SESSION['customer_id'];
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
$error = '';
$vehicle_id = (int)($_POST['vehicle_id'] ?? 0);
$appointment_date = $_POST['appointment_date'] ?? '';
$appointment_time = $_POST['appointment_time'] ?? '';
$remarks = trim($_POST['remarks'] ?? '');
$policyAccepted = isset($_POST['policy_accepted']);
$selectedIds = $_POST['services'] ?? $_GET['services'] ?? [];
if (!is_array($selectedIds)) $selectedIds = [];
$selectedIds = array_values(array_unique(array_filter(array_map('intval', $selectedIds))));

$vehicles = [];
$vehicleStmt = mysqli_prepare($conn, "SELECT id,brand,model,year,plate_number FROM vehicles WHERE user_id=? ORDER BY brand,model");
mysqli_stmt_bind_param($vehicleStmt, 'i', $user_id); mysqli_stmt_execute($vehicleStmt);
$vehicleResult = mysqli_stmt_get_result($vehicleStmt);
while ($row = mysqli_fetch_assoc($vehicleResult)) $vehicles[] = $row;
mysqli_stmt_close($vehicleStmt);

$services = [];
$serviceResult = mysqli_query($conn, "SELECT id,service_name,description,price,estimated_duration FROM services WHERE status='Active' ORDER BY service_name");
while ($serviceResult && $row = mysqli_fetch_assoc($serviceResult)) $services[] = $row;
$serviceCategories = service_categories_for($services);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) $error = 'Invalid form request. Please refresh and try again.';
    if (!$error && (!$vehicle_id || !$selectedIds || !$appointment_date || !$appointment_time)) $error = 'Please select a vehicle, at least one service, and an appointment schedule.';
    if (!$error && !$policyAccepted) $error = 'Accept the booking and refundable reservation-fee policy before continuing.';
    if (!$error && strtotime("$appointment_date $appointment_time") <= time()) $error = 'Please choose a future appointment schedule.';
    if (!$error && (int)date('N', strtotime($appointment_date)) === 7) $error = 'The service center is closed on Sundays.';
    if (!$error) {
        $hour = (int)date('H', strtotime($appointment_time));
        if ($hour < 8 || $hour >= 17) $error = 'Appointments are available from 8:00 AM to 5:00 PM.';
    }
    if (!$error) {
        $check = mysqli_prepare($conn, "SELECT id FROM vehicles WHERE id=? AND user_id=? LIMIT 1");
        mysqli_stmt_bind_param($check, 'ii', $vehicle_id, $user_id); mysqli_stmt_execute($check);
        if (mysqli_num_rows(mysqli_stmt_get_result($check)) !== 1) $error = 'Invalid vehicle selected.';
        mysqli_stmt_close($check);
    }
    if (!$error) {
        $slot = mysqli_prepare($conn, "SELECT id FROM reservations WHERE appointment_date=? AND appointment_time=? AND status NOT IN ('Cancelled','Completed') LIMIT 1");
        mysqli_stmt_bind_param($slot, 'ss', $appointment_date, $appointment_time); mysqli_stmt_execute($slot);
        if (mysqli_num_rows(mysqli_stmt_get_result($slot)) > 0) $error = 'That time is already booked. Please choose another schedule.';
        mysqli_stmt_close($slot);
    }
    $selectedServices = [];
    if (!$error) {
        $validById = [];
        foreach ($services as $service) $validById[(int)$service['id']] = $service;
        foreach ($selectedIds as $id) if (isset($validById[$id])) $selectedServices[] = $validById[$id];
        if (count($selectedServices) !== count($selectedIds)) $error = 'One or more selected services are no longer available.';
    }
    if (!$error) {
        $serviceNames = array_column($selectedServices, 'service_name');
        $serviceType = implode(', ', $serviceNames);
        $durationMinutes = array_sum(array_map(fn($item) => max(30,(int)($item['estimated_duration']??30))*2,$selectedServices));
        $start=date('Y-m-d H:i:s',strtotime($appointment_date.' '.$appointment_time));$end=date('Y-m-d H:i:s',strtotime($start)+$durationMinutes*60);
        $overlap=mysqli_prepare($conn,"SELECT id FROM reservations WHERE status NOT IN ('Cancelled','Completed') AND TIMESTAMP(appointment_date,appointment_time) < ? AND DATE_ADD(TIMESTAMP(appointment_date,appointment_time),INTERVAL scheduled_duration_minutes MINUTE) > ? LIMIT 1");mysqli_stmt_bind_param($overlap,'ss',$end,$start);mysqli_stmt_execute($overlap);if(mysqli_num_rows(mysqli_stmt_get_result($overlap))>0)$error='The selected time overlaps another appointment. Choose a later available slot.';mysqli_stmt_close($overlap);
        if($error){require_once __DIR__ . '/../includes/customer_header.php';echo '<div class="alert alert-danger">'.htmlspecialchars($error).'</div>';require_once __DIR__ . '/../includes/customer_footer.php';exit;}
        $reference = 'VSMS-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
        mysqli_begin_transaction($conn);
        try {
            $source='Website';$policyVersion='1.0-2026-10';$ip=$_SERVER['REMOTE_ADDR']??null;
            $insert = mysqli_prepare($conn, "INSERT INTO reservations(reference_number,user_id,customer_id,vehicle_id,service_type,appointment_date,appointment_time,remarks,status,mechanic_id,policy_version,policy_accepted_at,policy_source,policy_ip,scheduled_duration_minutes,reservation_fee_status) VALUES(?,?,(SELECT id FROM customers WHERE user_id=? LIMIT 1),?,?,?,?,?,'Pending',NULL,?,NOW(),?,?,?,'Awaiting Payment')");
            mysqli_stmt_bind_param($insert, 'siiisssssssi', $reference, $user_id, $user_id, $vehicle_id, $serviceType, $appointment_date, $appointment_time, $remarks,$policyVersion,$source,$ip,$durationMinutes);
            mysqli_stmt_execute($insert);
            $reservationId = mysqli_insert_id($conn);
            mysqli_stmt_close($insert);
            $payment=mysqli_prepare($conn,"INSERT INTO payments(reservation_id,amount,payment_method,status,payment_type,gross_amount) VALUES(?,200.00,'GCash','Awaiting Proof','Reservation Fee',200.00)");mysqli_stmt_bind_param($payment,'i',$reservationId);mysqli_stmt_execute($payment);$paymentId=mysqli_insert_id($conn);mysqli_stmt_close($payment);
            mysqli_query($conn,"UPDATE reservations SET reservation_fee_payment_id=".(int)$paymentId." WHERE id=".(int)$reservationId);
            $title = 'Booking submitted';
            $message = "Reservation $reference is waiting for approval.";
            $notice = mysqli_prepare($conn, "INSERT INTO notifications(user_id,title,message) VALUES(?,?,?)");
            mysqli_stmt_bind_param($notice, 'iss', $user_id, $title, $message); mysqli_stmt_execute($notice); mysqli_stmt_close($notice);
            mysqli_commit($conn);
            header('Location: ' . BASE_URL . '/customer/payments.php?reservation_fee=1');
            exit;
        } catch (Throwable $e) {
            mysqli_rollback($conn);
            $error = 'We could not submit the booking. Please try again.';
        }
    }
}

require_once __DIR__ . '/../includes/customer_header.php';
?>
<div class="customer-page-header"><div><h1>Book a Service</h1><p>Select your vehicle, choose one or more services, and set a convenient schedule.</p></div></div>
<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<?php if (!$vehicles): ?>
<div class="customer-card customer-empty"><i class="bi bi-car-front"></i><h2 class="h5 mt-2">Add a vehicle first</h2><p class="text-muted">A registered vehicle is required before booking a service.</p><a class="customer-primary-action" href="<?= BASE_URL ?>/customer/add_vehicle.php">Add Vehicle</a></div>
<?php else: ?>
<form method="post" id="customerBookingForm">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
    <section class="customer-card mb-3"><h2 class="h5 fw-bold mb-3">1. Select Vehicle</h2><select class="form-select" name="vehicle_id" required><option value="">Choose your vehicle</option><?php foreach ($vehicles as $vehicle): ?><option value="<?= (int)$vehicle['id'] ?>" <?= $vehicle_id===(int)$vehicle['id']?'selected':'' ?>><?= htmlspecialchars($vehicle['brand'].' '.$vehicle['model'].' • '.$vehicle['plate_number']) ?></option><?php endforeach; ?></select></section>
    <section class="customer-card mb-3"><h2 class="h5 fw-bold mb-1">2. Select Services</h2><p class="text-muted small mb-3">You can check more than one service.</p><div class="service-category-tabs"><button class="service-category-tab active" type="button" data-category="all">All</button><?php foreach($serviceCategories as $category): ?><button class="service-category-tab" type="button" data-category="<?= service_category_slug($category) ?>"><?= htmlspecialchars($category) ?></button><?php endforeach; ?></div><div class="service-estimate-grid"><?php foreach ($services as $service): ?><label class="service-choice" data-service-category="<?= service_category_slug(service_category($service['service_name'])) ?>"><input type="checkbox" name="services[]" value="<?= (int)$service['id'] ?>" data-price="<?= (float)$service['price'] ?>" <?= in_array((int)$service['id'],$selectedIds,true)?'checked':'' ?>><span class="service-choice-body"><span><h3><?= htmlspecialchars($service['service_name']) ?></h3><p><?= htmlspecialchars($service['description'] ?: 'Vehicle service and inspection.') ?></p><strong>₱<?= number_format((float)$service['price'],2) ?></strong></span></span></label><?php endforeach; ?></div><div class="d-flex justify-content-between align-items-center mt-3"><span class="text-muted"><span id="bookingServiceCount">0</span> selected</span><strong id="bookingServiceTotal">₱0.00 estimated</strong></div></section>
    <section class="customer-card mb-3"><h2 class="h5 fw-bold mb-3">3. Choose Schedule</h2><div class="row g-3"><div class="col-md-6"><label class="form-label">Date</label><input class="form-control" type="date" name="appointment_date" min="<?= date('Y-m-d') ?>" value="<?= htmlspecialchars($appointment_date) ?>" required></div><div class="col-md-6"><label class="form-label">Time</label><select class="form-select" name="appointment_time" required><option value="">Choose a time</option><?php foreach(['08:00','08:30','09:00','09:30','10:00','10:30','11:00','11:30','12:00','12:30','13:00','13:30','14:00','14:30','15:00','15:30','16:00','16:30'] as $time): ?><option value="<?= $time ?>" <?= $appointment_time===$time?'selected':'' ?>><?= date('g:i A',strtotime($time)) ?></option><?php endforeach; ?></select></div><div class="col-12"><label class="form-label">Vehicle concern or notes</label><textarea class="form-control" name="remarks" rows="3" placeholder="Tell us what you noticed about the vehicle..."><?= htmlspecialchars($remarks) ?></textarea></div></div></section>
    <section class="customer-card mb-3"><h2 class="h5 fw-bold">4. Review Policy & Reservation Fee</h2><div class="alert alert-light border"><strong>Refundable ₱200 reservation fee</strong><br>The fee reserves your requested schedule, is credited to your final bill, and is fully refunded if you or Luck Yuna Car Center cancels before inspection begins. A no-show may forfeit the fee.</div><div class="form-check"><input class="form-check-input" type="checkbox" name="policy_accepted" id="policyAccepted" required><label class="form-check-label" for="policyAccepted">I accept the booking, cancellation, refund, payment, and privacy policy.</label></div></section>
    <button class="customer-primary-action w-100" type="submit"><i class="bi bi-wallet2"></i> Continue to ₱200 Reservation Fee</button>
</form>
<script>
(() => { const boxes=[...document.querySelectorAll('input[name="services[]"]')],count=document.getElementById('bookingServiceCount'),total=document.getElementById('bookingServiceTotal'),tabs=[...document.querySelectorAll('.service-category-tab')],cards=[...document.querySelectorAll('[data-service-category]')]; const update=()=>{const selected=boxes.filter(b=>b.checked),amount=selected.reduce((s,b)=>s+Number(b.dataset.price||0),0);count.textContent=selected.length;total.textContent='₱'+amount.toLocaleString('en-PH',{minimumFractionDigits:2,maximumFractionDigits:2})+' estimated';};boxes.forEach(b=>b.addEventListener('change',update));tabs.forEach(tab=>tab.addEventListener('click',()=>{tabs.forEach(item=>item.classList.toggle('active',item===tab));cards.forEach(card=>card.hidden=tab.dataset.category!=='all'&&card.dataset.serviceCategory!==tab.dataset.category);}));update();})();
</script>
<?php endif; ?>
<?php require_once __DIR__ . '/../includes/customer_footer.php'; ?>
