<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/includes/config.php';

if (!empty($_SESSION['customer_id']) && ($_SESSION['customer_role'] ?? '') === 'customer') {
    header('Location: ' . BASE_URL . '/customer/dashboard.php');
    exit;
}

header('Location: ' . BASE_URL . '/login.php');
exit;
