<?php

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type");

require_once "../config/bootstrap.php";
$authUser = requireCustomer($conn);

if ($_SERVER["REQUEST_METHOD"] !== "GET") {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "message" => "Method not allowed."
    ]);

    exit;
}

$customer_id = $authUser["customer_id"];

try {

    $stmt = $conn->prepare("
        SELECT
            id,
            user_id,
            customer_id,
            brand,
            model,
            year,
            plate_number,
            color,
            vehicle_type,
            transmission,
            fuel_type,
            mileage,
            vin,
            created_at
        FROM vehicles
        WHERE customer_id = ?
        ORDER BY created_at DESC
    ");

    $stmt->bind_param(
        "i",
        $customer_id
    );

    $stmt->execute();

    $result = $stmt->get_result();

    $vehicles = [];

    while ($row = $result->fetch_assoc()) {

        $vehicles[] = [
            "id" => (int) $row["id"],

            "user_id" =>
                $row["user_id"] !== null
                    ? (int) $row["user_id"]
                    : null,

            "customer_id" =>
                $row["customer_id"] !== null
                    ? (int) $row["customer_id"]
                    : null,

            "brand" => $row["brand"],
            "model" => $row["model"],
            "year" => $row["year"],
            "plate_number" => $row["plate_number"],
            "color" => $row["color"],
            "vehicle_type" => $row["vehicle_type"],
            "transmission" => $row["transmission"],
            "fuel_type" => $row["fuel_type"],
            "mileage" => $row["mileage"],
            "vin" => $row["vin"],
            "created_at" => $row["created_at"]
        ];
    }

    echo json_encode([
        "success" => true,
        "message" => "Vehicles retrieved successfully.",
        "vehicles" => $vehicles
    ]);

} catch (Exception $e) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "Unable to retrieve vehicles."
    ]);
}
