<?php

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

require_once "../config/bootstrap.php";
$authUser = requireCustomer($conn);

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "message" => "Method not allowed."
    ]);

    exit;
}

$data = json_decode(
    file_get_contents("php://input"),
    true
);

if (!$data) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "Invalid request data."
    ]);

    exit;
}

$id = isset($data["id"])
    ? intval($data["id"])
    : 0;

$customer_id = $authUser["customer_id"];


if ($id <= 0 || $customer_id <= 0) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "Invalid vehicle information."
    ]);

    exit;
}


try {

    /*
     * Verify that this vehicle belongs
     * to the customer.
     */
    $vehicleStmt = $conn->prepare("
        SELECT id
        FROM vehicles
        WHERE id = ?
        AND customer_id = ?
        LIMIT 1
    ");

    $vehicleStmt->bind_param(
        "ii",
        $id,
        $customer_id
    );

    $vehicleStmt->execute();

    $vehicleResult =
        $vehicleStmt->get_result();


    if ($vehicleResult->num_rows === 0) {

        http_response_code(404);

        echo json_encode([
            "success" => false,
            "message" => "Vehicle not found."
        ]);

        exit;
    }


    /*
     * Delete vehicle.
     */
    $stmt = $conn->prepare("
        DELETE FROM vehicles
        WHERE id = ?
        AND customer_id = ?
    ");

    $stmt->bind_param(
        "ii",
        $id,
        $customer_id
    );

    $stmt->execute();


    echo json_encode([
        "success" => true,
        "message" =>
            "Vehicle deleted successfully."
    ]);

} catch (Exception $e) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" =>
            "Unable to delete vehicle. The vehicle may be connected to an existing appointment or service record."
    ]);
}
