<?php
require_once __DIR__ . '/../config/bootstrap.php';
requireMethod('POST');
$user=requireCustomer($conn);$userId=(int)$user['id'];$data=jsonInput();$id=(int)($data['reservation_id']??0);
$reason=trim($data['reason']??'');$details=trim($data['details']??'');
$reasons=['Service no longer needed','Change of mind','Schedule conflict','Price concern','Found another service provider','Vehicle unavailable','Emergency / unexpected situation','Other'];
if(!in_array($reason,$reasons,true)||($reason==='Other'&&$details==='')){http_response_code(422);echo json_encode(['success'=>false,'message'=>'Select a cancellation reason and explain Other.']);exit;}
$stmt=$conn->prepare("SELECT r.reservation_fee_payment_id,p.status payment_status FROM reservations r LEFT JOIN payments p ON p.id=r.reservation_fee_payment_id WHERE r.id=? AND r.user_id=? AND r.status IN ('Pending','Approved') LIMIT 1");
$stmt->bind_param('ii',$id,$userId);$stmt->execute();$booking=$stmt->get_result()->fetch_assoc();
if(!$booking){http_response_code(409);echo json_encode(['success'=>false,'message'=>'Only pending or approved appointments can be cancelled.']);exit;}
$paid=($booking['payment_status']??'')==='Paid';$eligibility=$paid?'Full ₱200 reservation-fee refund requested.':'No verified reservation fee — no refund is required.';$feeState=$paid?'Refund Requested':'Awaiting Payment';
$stmt=$conn->prepare("UPDATE reservations SET status='Cancelled',cancellation_reason=?,cancellation_details=?,refund_eligibility=?,reservation_fee_status=? WHERE id=? AND user_id=?");$stmt->bind_param('ssssii',$reason,$details,$eligibility,$feeState,$id,$userId);$stmt->execute();
if($paid&&(int)$booking['reservation_fee_payment_id']>0){$paymentId=(int)$booking['reservation_fee_payment_id'];$conn->query("UPDATE payments SET refund_status='Requested' WHERE id=$paymentId");}
$title='Appointment cancelled';$message="Reservation #$id was cancelled. $eligibility";$notice=$conn->prepare("INSERT INTO notifications(user_id,title,message,link_type,link_id) VALUES(?,?,?,'reservation',?)");$notice->bind_param('issi',$userId,$title,$message,$id);$notice->execute();
echo json_encode(['success'=>true,'message'=>'Appointment cancelled successfully.','refund_eligibility'=>$eligibility]);
