<?php
require_once __DIR__ . "/../config/bootstrap.php";
requireMethod("POST");
$user = requireCustomer($conn); $userId = (int) $user["id"];
$stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
$stmt->bind_param("i", $userId); $stmt->execute();
echo json_encode(["success" => true]);
