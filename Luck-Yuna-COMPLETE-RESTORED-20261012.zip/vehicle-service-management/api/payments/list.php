<?php
require_once __DIR__ . "/../config/bootstrap.php";
requireMethod("GET");
$user = requireCustomer($conn);
$userId = (int) $user["id"];
$optionalPaymentFields = implode(', ', [
 optionalColumn($conn, 'payments', 'p', 'proof_file'),
 optionalColumn($conn, 'payments', 'p', 'submitted_at'),
 optionalColumn($conn, 'payments', 'p', 'admin_notes'),
]);
$stmt = $conn->prepare("SELECT p.id AS payment_id, p.amount, p.payment_method, p.status AS payment_status,
 p.reference_number, p.paid_at, p.payment_type, $optionalPaymentFields, r.id AS reservation_id, r.service_type, r.appointment_date,
 r.appointment_time, v.brand, v.model, v.year, v.plate_number, v.color
 FROM payments p INNER JOIN reservations r ON p.reservation_id = r.id
 INNER JOIN vehicles v ON r.vehicle_id = v.id WHERE r.user_id = ? ORDER BY p.created_at DESC");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$items = [];
while ($row = $result->fetch_assoc()) {
    $row["payment_id"] = (int) $row["payment_id"];
    $row["reservation_id"] = (int) $row["reservation_id"];
    $row["amount"] = (float) $row["amount"];
    $items[] = $row;
}
echo json_encode(["success" => true, "payments" => $items]);
