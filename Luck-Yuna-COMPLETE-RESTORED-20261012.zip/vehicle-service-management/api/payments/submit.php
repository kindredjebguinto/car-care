<?php
require_once __DIR__ . "/../config/bootstrap.php";
requireMethod("POST");

$user = requireCustomer($conn);
$userId = (int) $user['id'];
$paymentId = (int) ($_POST['payment_id'] ?? 0);
$method = trim($_POST['payment_method'] ?? '');
$reference = trim($_POST['reference_number'] ?? '');
$onlineMethods = ['GCash', 'Maya', 'Bank Transfer', 'Card'];
$allowedMethods = array_merge(['Cash'], $onlineMethods);

if ($paymentId <= 0 || !in_array($method, $allowedMethods, true)) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Select a valid payment method.']);
    exit;
}

$stmt = $conn->prepare("SELECT p.id, p.proof_file, p.payment_type, p.reservation_id FROM payments p
    INNER JOIN reservations r ON p.reservation_id=r.id
    LEFT JOIN job_quotations q ON q.reservation_id=r.id
    WHERE p.id=? AND r.user_id=? AND (p.payment_type='Reservation Fee' OR q.status='Accepted')
    AND p.status IN ('Awaiting Proof','Rejected','Pay at Shop') LIMIT 1");
$stmt->bind_param('ii', $paymentId, $userId);
$stmt->execute();
$payment = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$payment) {
    http_response_code(409);
    echo json_encode(['success' => false, 'message' => 'Payment is not ready for submission. Refresh the booking and try again.']);
    exit;
}

if (($payment['payment_type'] ?? '') === 'Reservation Fee' && $method === 'Cash') {
    http_response_code(422);
    echo json_encode(['success'=>false,'message'=>'Cash at Shop is not available for the ₱200 app reservation fee. Choose an online payment method.']);
    exit;
}

if ($method === 'Cash') {
    $stmt = $conn->prepare("UPDATE payments SET payment_method='Cash', reference_number=NULL,
        proof_file=NULL, status='Pay at Shop', submitted_at=NOW(), paid_at=NULL,
        admin_notes=NULL WHERE id=? AND status IN ('Awaiting Proof','Rejected','Pay at Shop')");
    $stmt->bind_param('i', $paymentId);
    $ok = $stmt->execute();
    $stmt->close();
    if (!$ok) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Unable to select cash payment.']);
        exit;
    }
    $oldProof = $payment['proof_file'] ?? '';
    if ($oldProof !== '') {
        $oldPath = dirname(__DIR__, 2) . '/' . ltrim($oldProof, '/');
        if (is_file($oldPath)) @unlink($oldPath);
    }
    echo json_encode(['success' => true, 'message' => 'Cash payment selected. Please pay the exact amount at the service counter.']);
    exit;
}

if ($reference === '') {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Enter the transaction reference number.']);
    exit;
}
if (!isset($_FILES['proof']) || $_FILES['proof']['error'] !== UPLOAD_ERR_OK) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Attach a payment proof image.']);
    exit;
}

$file = $_FILES['proof'];
if ($file['size'] <= 0 || $file['size'] > 5 * 1024 * 1024) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Proof image must be 5 MB or smaller.']);
    exit;
}
$mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
$extensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
if (!isset($extensions[$mime])) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Use a JPG, PNG, or WEBP image.']);
    exit;
}

$uploadDir = dirname(__DIR__, 2) . '/uploads/payment_proofs';
if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true)) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Unable to prepare the proof upload folder.']);
    exit;
}
$filename = 'proof_' . $paymentId . '_' . bin2hex(random_bytes(8)) . '.' . $extensions[$mime];
$destination = $uploadDir . '/' . $filename;
if (!move_uploaded_file($file['tmp_name'], $destination)) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Unable to save payment proof.']);
    exit;
}

$relative = 'uploads/payment_proofs/' . $filename;
$stmt = $conn->prepare("UPDATE payments SET payment_method=?, reference_number=?, proof_file=?,
    status='Under Review', submitted_at=NOW(), paid_at=NULL, admin_notes=NULL
    WHERE id=? AND status IN ('Awaiting Proof','Rejected','Pay at Shop')");
$stmt->bind_param('sssi', $method, $reference, $relative, $paymentId);
$ok = $stmt->execute();
$changed = $stmt->affected_rows > 0;
$stmt->close();

if (!$ok || !$changed) {
    @unlink($destination);
    http_response_code(409);
    echo json_encode(['success' => false, 'message' => 'Payment changed before submission. Refresh and try again.']);
    exit;
}
if (($payment['payment_type'] ?? '') === 'Reservation Fee') {
    $reservationId = (int) $payment['reservation_id'];
    $conn->query("UPDATE reservations SET reservation_fee_status='Under Review' WHERE id=$reservationId");
}

$oldProof = $payment['proof_file'] ?? '';
if ($oldProof !== '' && $oldProof !== $relative) {
    $oldPath = dirname(__DIR__, 2) . '/' . ltrim($oldProof, '/');
    if (is_file($oldPath)) @unlink($oldPath);
}

echo json_encode(['success' => true, 'message' => 'Payment proof submitted for verification.']);
