<?php
require_once __DIR__ . "/../config/bootstrap.php";
requireMethod("GET");
$user = requireCustomer($conn);
$userId = (int) $user["id"];
$id = (int) ($_GET["id"] ?? 0);
$stmt = $conn->prepare("SELECT p.id AS payment_id, p.amount, p.payment_method, p.status AS payment_status,
 p.reference_number, p.paid_at, r.id AS reservation_id, r.reference_number AS reservation_reference, r.service_type, r.appointment_date,
 r.appointment_time, u.fullname, u.email, v.brand, v.model, v.year, v.plate_number, v.color
 ,q.subtotal,q.discount,q.tax,q.grand_total
 FROM payments p INNER JOIN reservations r ON p.reservation_id = r.id
 INNER JOIN users u ON r.user_id = u.id INNER JOIN vehicles v ON r.vehicle_id = v.id
 LEFT JOIN job_quotations q ON q.reservation_id=r.id
 WHERE p.id = ? AND r.user_id = ? AND p.status = 'Paid' LIMIT 1");
$stmt->bind_param("ii", $id, $userId);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
if (!$row) {
    http_response_code(404);
    echo json_encode(["success" => false, "message" => "Receipt not found."]);
    exit;
}
$row["payment_id"] = (int) $row["payment_id"];
$row["reservation_id"] = (int) $row["reservation_id"];
$row["amount"] = (float) $row["amount"];
foreach (["subtotal","discount","tax","grand_total"] as $key) $row[$key] = $row[$key] === null ? null : (float) $row[$key];
echo json_encode(["success" => true, "receipt" => $row]);
