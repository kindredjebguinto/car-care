<?php
require_once __DIR__.'/../config/bootstrap.php';requireMethod('POST');$user=requireCustomer($conn);$data=jsonInput();
$reservationId=(int)($data['reservation_id']??0);$rating=(int)($data['rating']??0);$review=trim($data['review']??'');$userId=(int)$user['id'];
if($rating<1||$rating>5){http_response_code(422);echo json_encode(['success'=>false,'message'=>'Choose a rating from 1 to 5 stars.']);exit;}
$stmt=$conn->prepare("INSERT INTO service_feedback(reservation_id,user_id,rating,review) SELECT id,user_id,?,? FROM reservations WHERE id=? AND user_id=? AND status='Completed' ON DUPLICATE KEY UPDATE rating=VALUES(rating),review=VALUES(review),created_at=NOW()");
$stmt->bind_param('isii',$rating,$review,$reservationId,$userId);$stmt->execute();
if(!$stmt->affected_rows){http_response_code(409);echo json_encode(['success'=>false,'message'=>'Feedback is available only for your completed service.']);exit;}
echo json_encode(['success'=>true,'message'=>'Thank you for your feedback.']);
