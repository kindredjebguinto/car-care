<?php
require_once __DIR__ . "/../config/bootstrap.php";
requireMethod("GET");
$user = requireCustomer($conn);
echo json_encode(["success" => true, "profile" => [
    "id" => (int) $user["id"], "customer_id" => $user["customer_id"],
    "fullname" => $user["fullname"], "email" => $user["email"],
    "phone" => $user["phone"], "address" => $user["address"]
]]);
