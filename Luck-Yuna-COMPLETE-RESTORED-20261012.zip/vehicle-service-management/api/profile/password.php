<?php
require_once __DIR__ . "/../config/bootstrap.php";
requireMethod("POST");
$user = requireCustomer($conn);
$userId = (int) $user["id"];
$data = jsonInput();
$current = $data["current_password"] ?? "";
$new = $data["new_password"] ?? "";
$confirm = $data["confirm_password"] ?? "";
$stmt = $conn->prepare("SELECT password FROM users WHERE id = ? LIMIT 1");
$stmt->bind_param("i", $userId);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
if (!$row || !password_verify($current, $row["password"])) {
    http_response_code(400); echo json_encode(["success" => false, "message" => "Current password is incorrect."]); exit;
}
if (strlen($new) < 8) {
    http_response_code(400); echo json_encode(["success" => false, "message" => "New password must be at least 8 characters."]); exit;
}
if ($new !== $confirm) {
    http_response_code(400); echo json_encode(["success" => false, "message" => "New passwords do not match."]); exit;
}
$hash = password_hash($new, PASSWORD_DEFAULT);
$stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
$stmt->bind_param("si", $hash, $userId);
$stmt->execute();
echo json_encode(["success" => true, "message" => "Password changed successfully."]);
