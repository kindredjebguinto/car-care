<?php

require_once __DIR__ . "/config/database.php";

echo json_encode([
    "success" => true,
    "message" => "Vehicle Service Management API is running."
]);