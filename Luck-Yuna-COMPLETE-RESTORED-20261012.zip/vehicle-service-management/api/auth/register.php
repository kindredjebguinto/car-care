<?php

require_once __DIR__ . "/../config/database.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "message" => "Method not allowed."
    ]);

    exit;
}

$input = json_decode(file_get_contents("php://input"), true);

$fullname = trim($input["fullname"] ?? "");
$email = trim($input["email"] ?? "");
$password = $input["password"] ?? "";
$phone = trim($input["phone"] ?? "");
$address = trim($input["address"] ?? "");

if ($fullname === "" || $email === "" || $password === "") {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "Full name, email and password are required."
    ]);

    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "Invalid email address."
    ]);

    exit;
}

if (strlen($password) < 8) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "Password must contain at least 8 characters."
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Check email
|--------------------------------------------------------------------------
*/

$check = $conn->prepare("
    SELECT id
    FROM users
    WHERE email = ?
    LIMIT 1
");

$check->bind_param("s", $email);
$check->execute();

if ($check->get_result()->num_rows > 0) {

    http_response_code(409);

    echo json_encode([
        "success" => false,
        "message" => "Email is already registered."
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Transaction
|--------------------------------------------------------------------------
*/

$conn->begin_transaction();

try {

    $hashedPassword = password_hash(
        $password,
        PASSWORD_DEFAULT
    );

    $role = "customer";

    $userStmt = $conn->prepare("
        INSERT INTO users
        (
            fullname,
            email,
            password,
            role
        )
        VALUES (?, ?, ?, ?)
    ");

    $userStmt->bind_param(
        "ssss",
        $fullname,
        $email,
        $hashedPassword,
        $role
    );

    $userStmt->execute();

    $userId = $conn->insert_id;

    /*
    |--------------------------------------------------------------------------
    | Customer profile
    |--------------------------------------------------------------------------
    */

    $customerStmt = $conn->prepare("
        INSERT INTO customers
        (
            user_id,
            fullname,
            email,
            phone,
            address
        )
        VALUES (?, ?, ?, ?, ?)
    ");

    $customerStmt->bind_param(
        "issss",
        $userId,
        $fullname,
        $email,
        $phone,
        $address
    );

    $customerStmt->execute();

    $customerId = $conn->insert_id;

    $conn->commit();

    http_response_code(201);

    echo json_encode([
        "success" => true,
        "message" => "Account created successfully.",
        "user" => [
            "id" => $userId,
            "fullname" => $fullname,
            "email" => $email,
            "role" => "customer"
        ],
        "customer" => [
            "id" => $customerId,
            "user_id" => $userId
        ]
    ]);

} catch (Throwable $e) {

    $conn->rollback();

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "Unable to create account."
    ]);
}