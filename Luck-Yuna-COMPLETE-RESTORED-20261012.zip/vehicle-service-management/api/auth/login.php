<?php

require_once __DIR__ . "/../config/database.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "message" => "Method not allowed."
    ]);

    exit;
}

$input = json_decode(file_get_contents("php://input"), true);

$email = trim($input["email"] ?? "");
$password = $input["password"] ?? "";

if ($email === "" || $password === "") {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "Email and password are required."
    ]);

    exit;
}

$stmt = $conn->prepare("
    SELECT
        id,
        fullname,
        email,
        password,
        role
    FROM users
    WHERE email = ?
    LIMIT 1
");

$stmt->bind_param("s", $email);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows !== 1) {

    http_response_code(401);

    echo json_encode([
        "success" => false,
        "message" => "Invalid email or password."
    ]);

    exit;
}

$user = $result->fetch_assoc();

if (!password_verify($password, $user["password"])) {

    http_response_code(401);

    echo json_encode([
        "success" => false,
        "message" => "Invalid email or password."
    ]);

    exit;
}

if ($user["role"] !== "customer") {

    http_response_code(403);

    echo json_encode([
        "success" => false,
        "message" => "This application is for customers only."
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Find customer profile
|--------------------------------------------------------------------------
*/

$customerStmt = $conn->prepare("
    SELECT *
    FROM customers
    WHERE user_id = ?
    LIMIT 1
");

$customerStmt->bind_param("i", $user["id"]);
$customerStmt->execute();

$customerResult = $customerStmt->get_result();

$customer = null;

if ($customerResult->num_rows === 1) {
    $customer = $customerResult->fetch_assoc();
}

/*
|--------------------------------------------------------------------------
| Generate API Token
|--------------------------------------------------------------------------
*/

$token = bin2hex(random_bytes(32));

$tokenHash = hash("sha256", $token);

$expiresAt = date(
    "Y-m-d H:i:s",
    strtotime("+7 days")
);

$tokenStmt = $conn->prepare("
    INSERT INTO api_tokens
    (
        user_id,
        token_hash,
        expires_at
    )
    VALUES (?, ?, ?)
");

$tokenStmt->bind_param(
    "iss",
    $user["id"],
    $tokenHash,
    $expiresAt
);

$tokenStmt->execute();

/*
|--------------------------------------------------------------------------
| Successful Login
|--------------------------------------------------------------------------
*/

echo json_encode([
    "success" => true,
    "message" => "Login successful.",

    "token" => $token,

    "expires_at" => $expiresAt,

    "user" => [
        "id" => (int) $user["id"],
        "fullname" => $user["fullname"],
        "email" => $user["email"],
        "role" => $user["role"]
    ],

    "customer" => $customer
]);
