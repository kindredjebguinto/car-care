<?php
require_once __DIR__ . "/../config/bootstrap.php";
requireMethod("POST");
$data = jsonInput();
$email = trim($data["email"] ?? "");
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400); echo json_encode(["success" => false, "message" => "Enter a valid email address."]); exit;
}
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ? AND role = 'customer' LIMIT 1");
$stmt->bind_param("s", $email); $stmt->execute(); $user = $stmt->get_result()->fetch_assoc();
if ($user) {
    $userId = (int) $user["id"];
    $request = $conn->prepare("INSERT INTO password_reset_requests (user_id, email, status) VALUES (?, ?, 'Pending')");
    $request->bind_param("is", $userId, $email); $request->execute();
}
echo json_encode(["success" => true, "message" => "If the account exists, a password-reset request was sent to the administrator."]);
