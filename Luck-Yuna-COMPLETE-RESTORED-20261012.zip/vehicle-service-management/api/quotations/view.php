<?php
require_once __DIR__ . "/../config/bootstrap.php";
requireMethod("GET");
$user = requireCustomer($conn);
$reservationId = intval($_GET["reservation_id"] ?? 0);

$stmt = $conn->prepare("SELECT q.*, r.reference_number, r.service_type, v.brand, v.model, v.plate_number
 FROM job_quotations q INNER JOIN reservations r ON q.reservation_id=r.id
 INNER JOIN vehicles v ON r.vehicle_id=v.id
 WHERE q.reservation_id=? AND r.user_id=? AND q.status<>'Draft' LIMIT 1");
$userId = (int)$user["id"];
$stmt->bind_param("ii", $reservationId, $userId); $stmt->execute();
$quote = $stmt->get_result()->fetch_assoc(); $stmt->close();
if (!$quote) { echo json_encode(["success"=>true,"quotation"=>null]); exit; }

$quoteId=(int)$quote["id"];
$stmt=$conn->prepare("SELECT id,item_type,description,quantity,unit_price,amount,is_additional,customer_decision FROM job_quotation_items WHERE quotation_id=? ORDER BY id");
$stmt->bind_param("i",$quoteId); $stmt->execute(); $result=$stmt->get_result(); $items=[];
while($item=$result->fetch_assoc()) {
    $item["id"]=(int)$item["id"];
    foreach(["quantity","unit_price","amount"] as $key) $item[$key]=(float)$item[$key];
    $item["is_additional"]=(bool)$item["is_additional"];
    $items[]=$item;
}
$stmt->close();
$quote["id"]=$quoteId; $quote["reservation_id"]=(int)$quote["reservation_id"];
foreach(["subtotal","discount","tax","grand_total"] as $key) $quote[$key]=(float)$quote[$key];
$quote["items"]=$items;
echo json_encode(["success"=>true,"quotation"=>$quote]);
