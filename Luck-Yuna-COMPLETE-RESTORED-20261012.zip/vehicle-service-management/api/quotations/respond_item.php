<?php
require_once __DIR__ . '/../config/bootstrap.php';
requireMethod('POST');
$user = requireCustomer($conn);
$data = jsonInput();
$itemId = (int)($data['item_id'] ?? 0);
$decision = $data['decision'] ?? '';
if (!in_array($decision, ['Accepted','Rejected'], true)) {
    http_response_code(422);
    echo json_encode(['success'=>false,'message'=>'Choose Accepted or Rejected.']);
    exit;
}
$userId = (int)$user['id'];
$stmt = $conn->prepare("UPDATE job_quotation_items i INNER JOIN job_quotations q ON q.id=i.quotation_id INNER JOIN reservations r ON r.id=q.reservation_id SET i.customer_decision=? WHERE i.id=? AND i.is_additional=1 AND i.customer_decision='Pending' AND r.user_id=? AND r.status NOT IN ('Cancelled','Completed')");
$stmt->bind_param('sii', $decision, $itemId, $userId);
$stmt->execute();
if ($stmt->affected_rows < 1) {
    http_response_code(409);
    echo json_encode(['success'=>false,'message'=>'This additional-work item can no longer be changed.']);
    exit;
}
echo json_encode(['success'=>true,'message'=>'Additional work '.strtolower($decision).'. The original approved work will continue.']);
