# Luck Yuna Car Center — Full Workflow Update

1. Back up the website files and database.
2. Extract the website ZIP directly inside `public_html` and overwrite files.
3. Do not delete `private_config.php` beside `public_html`.
4. In phpMyAdmin, select the actual hosting database first.
5. Import `database/full_workflow_upgrade_20261011.sql` once.
6. Log out of the admin portal and sign in again so the Manager role is loaded.
7. Test a new booking: accept policy, create booking, pay ₱200, verify payment as admin, then approve the booking.

The ₱200 reservation fee is credited against the final quotation balance. A customer or admin cancellation before inspection creates a full reservation-fee refund request.

The Flutter app now defaults to `https://lyc-vsms.x10.mx/api`. Lock-screen push notifications still require Firebase project credentials.
