# Luck Yuna Car Center — XAMPP + Flutter Setup

## Website and admin

1. Copy the complete `Vehicle-Service-System` folder to `C:\xampp\htdocs\`.
2. Start Apache and MySQL in XAMPP.
3. Open phpMyAdmin and create/select the `vehicle_service_system` database.
4. For a new database, import these files in this exact order:
   1. `vehicle-service-management/database/vehicle_service_system (3).sql`
   2. `vehicle-service-management/database/mobile_api_migration.sql`
   3. `vehicle-service-management/database/import_complete_service_catalog.sql`
   4. `vehicle-service-management/database/full_workflow_upgrade_20261011.sql`
5. If your database already exists, back it up first and import only files 2–4. Duplicate-column messages mean that migration was already imported and should not be imported again.
6. Customer website:
   `http://localhost/Vehicle-Service-System/vehicle-service-management/`
7. Admin website:
   `http://localhost/Vehicle-Service-System/vehicle-service-management-admin/`

## Flutter Android emulator

1. Open `vsm_customer` in VS Code or Android Studio.
2. Run `flutter clean`.
3. Run `flutter pub get`.
4. Start the Android emulator.
5. Run `flutter run`.

The Flutter project is configured to access XAMPP through `10.0.2.2`.

Lock-screen push notifications require a Firebase project, `google-services.json`, and a hosting-side Firebase service credential. In-app notifications, unread red dots, and notification links work without Firebase. Do not use a sample Firebase credential in production.

For the hosted API instead, run:

`flutter run --dart-define=API_BASE_URL=https://lyc-vsms.x10.mx/api`

For a hosted release APK:

`flutter build apk --release --dart-define=API_BASE_URL=https://lyc-vsms.x10.mx/api`
